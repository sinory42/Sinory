<script src="<?= BASEURL; ?>/js/jquery-3.3.1.slim.min.js"></script>
<script src="<?= BASEURL; ?>/js/popper.min.js"></script>
<script src="<?= BASEURL; ?>/js/bootstrap.min.js" ></script>
</body>
</html>